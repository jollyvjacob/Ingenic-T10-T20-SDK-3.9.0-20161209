var searchData=
[
  ['ingenic_20smart_20video_20platform',['Ingenic Smart Video Platform',['../index.html',1,'']]]
];
