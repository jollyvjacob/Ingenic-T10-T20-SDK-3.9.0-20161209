var searchData=
[
  ['coverdata',['coverData',['../structcover_data.html',1,'']]]
];
