var searchData=
[
  ['fs_5fext_5fchannel',['FS_EXT_CHANNEL',['../group___i_m_p___frame_source.html#gga155b3408c5b20686f020a351a56d34a1aa7d8a412ff0cf06f92fad8b1a976bd9f',1,'imp_framesource.h']]],
  ['fs_5fphy_5fchannel',['FS_PHY_CHANNEL',['../group___i_m_p___frame_source.html#gga155b3408c5b20686f020a351a56d34a1aa44fd626db4a97c40ffc9f231396d67c',1,'imp_framesource.h']]],
  ['full',['Full',['../group___sysutils___battery.html#gga91be632ce036c3567e44ea25c6817cdda8b7c5cd8bd8eb51ee6d3fd0eac584679',1,'su_battery.h']]]
];
