var searchData=
[
  ['tx_5fsensor_5fcontrol_5finterface_5fi2c',['TX_SENSOR_CONTROL_INTERFACE_I2C',['../group___i_m_p___i_s_p.html#gga38ee4d645812c12b28cd37d5320ccfb2a97f8ef07011482201851230c9e944752',1,'imp_isp.h']]],
  ['tx_5fsensor_5fcontrol_5finterface_5fspi',['TX_SENSOR_CONTROL_INTERFACE_SPI',['../group___i_m_p___i_s_p.html#gga38ee4d645812c12b28cd37d5320ccfb2aacc0aa36ed6d54a7064f49eb987f7bc6',1,'imp_isp.h']]]
];
