var searchData=
[
  ['n',['n',['../struct_i_m_p_encoder_attr_h264_h_skip.html#a76f11d9a0a47b94f72c2d0e77fb32240',1,'IMPEncoderAttrH264HSkip']]],
  ['name',['name',['../struct_i_m_p_sensor_info.html#abc1e86d7c344fe34ff09e72d4595ab7e',1,'IMPSensorInfo::name()'],['../group___i_m_p___audio.html#gacd328517a6cf718155c2e6e22b671ca9',1,'IMPAudioEncEncoder::name()'],['../group___i_m_p___audio.html#gacd328517a6cf718155c2e6e22b671ca9',1,'IMPAudioDecDecoder::name()']]],
  ['nrkeepstream',['nrKeepStream',['../struct_i_m_p_decoder_attr.html#a38b94b5b869ebb6a9cdb3220f647253f',1,'IMPDecoderAttr']]],
  ['nrvbs',['nrVBs',['../struct_i_m_p_f_s_chn_attr.html#a61fe3b4b83d96315a6004dabac08d4f7',1,'IMPFSChnAttr']]],
  ['numperfrm',['numPerFrm',['../group___i_m_p___audio.html#gae510449fcca6e2545e60579e5380dea8',1,'IMPAudioIOAttr']]]
];
