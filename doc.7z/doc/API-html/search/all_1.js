var searchData=
[
  ['benable',['bEnable',['../struct_i_m_p_encoder_r_o_i_cfg.html#af9ec249954751d46af361b259b10dd82',1,'IMPEncoderROICfg']]],
  ['bgain',['bgain',['../structisp__core__wb__attr.html#a545465fa1af0708dbd6c98443f06438f',1,'isp_core_wb_attr']]],
  ['bgalhpa',['bgAlhpa',['../struct_i_m_p_o_s_d_grp_rgn_attr.html#aba570fe9f2c51a3fccefd2c5a43e6123',1,'IMPOSDGrpRgnAttr']]],
  ['bitmapdata',['bitmapData',['../union_i_m_p_o_s_d_rgn_attr_data.html#af30baa550426466190740874f80b4f05',1,'IMPOSDRgnAttrData']]],
  ['bitwidth',['bitwidth',['../group___i_m_p___audio.html#gaeaf02b467f4af931b8a37f0403ecb9c7',1,'IMPAudioIOAttr::bitwidth()'],['../group___i_m_p___audio.html#gaeaf02b467f4af931b8a37f0403ecb9c7',1,'IMPAudioFrame::bitwidth()']]],
  ['black_5flevel',['black_level',['../struct_i_m_p_i_s_p_drc_attr.html#a7357cfbe2a6140217806733a6e30d51e',1,'IMPISPDrcAttr']]],
  ['block',['BLOCK',['../group___i_m_p___audio.html#gga7f9bbf0ae482fa7e68855f4bf68c4a1ba02fc27068fe9a3c151ffcc08ec5bb65d',1,'imp_audio.h']]],
  ['brelatedqp',['bRelatedQp',['../struct_i_m_p_encoder_r_o_i_cfg.html#a8cd1a398eae72c5838eed771e61de30a',1,'IMPEncoderROICfg']]],
  ['bufsize',['bufSize',['../struct_i_m_p_encoder_attr.html#ae6c99dcf7758f2e62228c38fcf1b7d41',1,'IMPEncoderAttr::bufSize()'],['../group___i_m_p___audio.html#ga9e00b7e92141a7ca54622a6e651a65f8',1,'IMPAudioEncChnAttr::bufSize()'],['../group___i_m_p___audio.html#ga9e00b7e92141a7ca54622a6e651a65f8',1,'IMPAudioDecChnAttr::bufSize()']]],
  ['bus_5fnum',['bus_num',['../struct_i_m_p_s_p_i_info.html#af52aeec8ebe03bc6097d6a6438559071',1,'IMPSPIInfo']]]
];
