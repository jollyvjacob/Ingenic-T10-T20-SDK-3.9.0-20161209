var searchData=
[
  ['data',['data',['../struct_i_m_p_o_s_d_rgn_attr.html#a7d65fefb322442fb37da6d16990027ac',1,'IMPOSDRgnAttr']]],
  ['datatype',['dataType',['../struct_i_m_p_encoder_pack.html#a825c4f7c0ed45f1a4bab7530de62d76a',1,'IMPEncoderPack']]],
  ['decattr',['decAttr',['../struct_i_m_p_decoder_c_h_n_attr.html#a382cdb979dda46d85a33be1dcb197b91',1,'IMPDecoderCHNAttr']]],
  ['decodernal',['decoderNal',['../struct_i_m_p_decoder_stream.html#a83af695d9e992b6e60361b26781b9d18',1,'IMPDecoderStream']]],
  ['dectype',['decType',['../struct_i_m_p_decoder_attr.html#aaca5f82d924a74f24e4559d531479ced',1,'IMPDecoderAttr']]],
  ['demaskcnt',['demaskCnt',['../struct_i_m_p_encoder_attr_h264_demask.html#a256478de947ff6253375ecfe8a92a954',1,'IMPEncoderAttrH264Demask']]],
  ['demaskthresd',['demaskThresd',['../struct_i_m_p_encoder_attr_h264_demask.html#a36545eaa4bb6511cb3b8cb159365dc32',1,'IMPEncoderAttrH264Demask']]],
  ['deviceid',['deviceID',['../struct_i_m_p_cell.html#a3ff2f370b9d3dfdcdc73230be37ddcb6',1,'IMPCell']]],
  ['dgain',['dgain',['../struct_i_m_p_i_s_p_e_v_attr.html#a8c8abdcc487cc055fdfc2e06610532fc',1,'IMPISPEVAttr']]],
  ['dniqp',['dnIQp',['../struct_i_m_p_encoder_attr_h264_denoise.html#ae915d8bb4c1d2d6ddddf1e0bd2ac823e',1,'IMPEncoderAttrH264Denoise']]],
  ['dnpqp',['dnPQp',['../struct_i_m_p_encoder_attr_h264_denoise.html#a17ef3c00e33d6bd65fe0b558ff99e4d3',1,'IMPEncoderAttrH264Denoise']]],
  ['dntype',['dnType',['../struct_i_m_p_encoder_attr_h264_denoise.html#ab621559721ed430d2b9137d6807a4bf1',1,'IMPEncoderAttrH264Denoise']]],
  ['drc_5fstrength',['drc_strength',['../struct_i_m_p_i_s_p_drc_attr.html#af48d2ff007d96c2a2aa9cb697865ce1e',1,'IMPISPDrcAttr']]]
];
