var searchData=
[
  ['cbus_5ftype',['cbus_type',['../struct_i_m_p_sensor_info.html#a8aa6f715914bd7b43ecdf648e4d55060',1,'IMPSensorInfo']]],
  ['changepos',['changePos',['../struct_i_m_p_encoder_attr_h264_v_b_r.html#aef37516530135dce532bf51842845726',1,'IMPEncoderAttrH264VBR']]],
  ['charging',['Charging',['../group___sysutils___battery.html#gga91be632ce036c3567e44ea25c6817cdda5a86ae1482947377a116685c168d1773',1,'su_battery.h']]],
  ['chnbusynum',['chnBusyNum',['../group___i_m_p___audio.html#ga03a9d760ecd529e9684e7bde3203548f',1,'IMPAudioOChnState']]],
  ['chncnt',['chnCnt',['../group___i_m_p___audio.html#gad5d4292ea021c4630a9aa06296018e93',1,'IMPAudioIOAttr']]],
  ['chnfreenum',['chnFreeNum',['../group___i_m_p___audio.html#gacfe0b3687c7e8b5287e06bd3e645eb04',1,'IMPAudioOChnState']]],
  ['chntotalnum',['chnTotalNum',['../group___i_m_p___audio.html#ga558a8f313528f920f73f59c16de4751d',1,'IMPAudioOChnState']]],
  ['chr',['chr',['../struct_s_u_model_num.html#a668d6d7474c173fe106b563b785e66db',1,'SUModelNum::chr()'],['../struct_s_u_version.html#a668d6d7474c173fe106b563b785e66db',1,'SUVersion::chr()'],['../union_s_u_dev_i_d.html#a668d6d7474c173fe106b563b785e66db',1,'SUDevID::chr()']]],
  ['color',['color',['../structline_rect_data.html#a66b2ef8398a8bbb0f5816f22a7b138da',1,'lineRectData::color()'],['../structcover_data.html#a66b2ef8398a8bbb0f5816f22a7b138da',1,'coverData::color()']]],
  ['compressiongaindb',['CompressionGaindB',['../group___i_m_p___audio.html#gafa7cd850575e0a605f4cbcfdd7514ac5',1,'IMPAudioAgcConfig']]],
  ['coverdata',['coverData',['../structcover_data.html',1,'coverData'],['../union_i_m_p_o_s_d_rgn_attr_data.html#a80539b7df7ca7a8dc548644e3a9a520b',1,'IMPOSDRgnAttrData::coverData()']]],
  ['crop',['crop',['../struct_i_m_p_f_s_chn_attr.html#a897937226d6da603896bbb99553fb229',1,'IMPFSChnAttr::crop()'],['../struct_i_m_p_encoder_attr.html#a14fe62879245a5bf62f1f34906c58257',1,'IMPEncoderAttr::crop()']]],
  ['curpacks',['curPacks',['../struct_i_m_p_encoder_c_h_n_stat.html#ae8559cfe8405d76c2f16f574032779cf',1,'IMPEncoderCHNStat']]]
];
