var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy",
  1: "cilps",
  2: "is",
  3: "is",
  4: "abcdefghiklmnopqrstuvwxy",
  5: "i",
  6: "eils",
  7: "abcdefiklnoptu",
  8: "ims",
  9: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "结构体",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "类型定义",
  6: "枚举",
  7: "枚举值",
  8: "组",
  9: "页"
};

