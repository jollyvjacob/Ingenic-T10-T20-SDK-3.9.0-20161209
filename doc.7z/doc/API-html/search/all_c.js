var searchData=
[
  ['n',['n',['../struct_i_m_p_encoder_attr_h264_h_skip.html#a76f11d9a0a47b94f72c2d0e77fb32240',1,'IMPEncoderAttrH264HSkip']]],
  ['name',['name',['../struct_i_m_p_sensor_info.html#abc1e86d7c344fe34ff09e72d4595ab7e',1,'IMPSensorInfo::name()'],['../group___i_m_p___audio.html#gacd328517a6cf718155c2e6e22b671ca9',1,'IMPAudioEncEncoder::name()'],['../group___i_m_p___audio.html#gacd328517a6cf718155c2e6e22b671ca9',1,'IMPAudioDecDecoder::name()']]],
  ['noblock',['NOBLOCK',['../group___i_m_p___audio.html#gga7f9bbf0ae482fa7e68855f4bf68c4a1ba2be9044f7a5785fb4db63bae7d099a9b',1,'imp_audio.h']]],
  ['nrkeepstream',['nrKeepStream',['../struct_i_m_p_decoder_attr.html#a38b94b5b869ebb6a9cdb3220f647253f',1,'IMPDecoderAttr']]],
  ['nrvbs',['nrVBs',['../struct_i_m_p_f_s_chn_attr.html#a61fe3b4b83d96315a6004dabac08d4f7',1,'IMPFSChnAttr']]],
  ['ns_5fhigh',['NS_HIGH',['../group___i_m_p___audio.html#gga6685d9ae470366ad2d95e8e32c7527fcadacc47f47a5a05d646fc33b7ec007fbb',1,'imp_audio.h']]],
  ['ns_5flow',['NS_LOW',['../group___i_m_p___audio.html#gga6685d9ae470366ad2d95e8e32c7527fcac734df19993daf3396374b293197ea71',1,'imp_audio.h']]],
  ['ns_5fmoderate',['NS_MODERATE',['../group___i_m_p___audio.html#gga6685d9ae470366ad2d95e8e32c7527fca6767e6362ab12a700ef3fe57374ff867',1,'imp_audio.h']]],
  ['ns_5fveryhigh',['NS_VERYHIGH',['../group___i_m_p___audio.html#gga6685d9ae470366ad2d95e8e32c7527fcafde6cb5dee40e524af25ad55d44d9379',1,'imp_audio.h']]],
  ['numperfrm',['numPerFrm',['../group___i_m_p___audio.html#gae510449fcca6e2545e60579e5380dea8',1,'IMPAudioIOAttr']]]
];
