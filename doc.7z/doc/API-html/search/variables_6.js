var searchData=
[
  ['gain_5flog2',['gain_log2',['../struct_i_m_p_i_s_p_e_v_attr.html#a54fcd5f2b278f8690bc9a5ea96aad3b3',1,'IMPISPEVAttr']]],
  ['galphaen',['gAlphaEn',['../struct_i_m_p_o_s_d_grp_rgn_attr.html#aa6dc0fcaed7b3c7408f00695454605db',1,'IMPOSDGrpRgnAttr']]],
  ['gamma',['gamma',['../struct_i_m_p_i_s_p_gamma.html#a938265016058f7e4d028d8a81ec1187a',1,'IMPISPGamma']]],
  ['getparam',['GetParam',['../struct_i_m_p_i_v_s_interface.html#a99fdd641bc57ccc340137c2edb3cd3da',1,'IMPIVSInterface']]],
  ['getresult',['GetResult',['../struct_i_m_p_i_v_s_interface.html#a5d1dc2edce4ff357520a8581ef452640',1,'IMPIVSInterface']]],
  ['gopqpstep',['GOPQPStep',['../struct_i_m_p_encoder_attr_h264_c_b_r.html#ac4e923b93296149c4aa9683dc5bd4951',1,'IMPEncoderAttrH264CBR::GOPQPStep()'],['../struct_i_m_p_encoder_attr_h264_v_b_r.html#ac4e923b93296149c4aa9683dc5bd4951',1,'IMPEncoderAttrH264VBR::GOPQPStep()']]],
  ['goprelation',['GOPRelation',['../struct_i_m_p_encoder_attr_h264_c_b_r.html#af70f20302dec30c33e4f15734422a33f',1,'IMPEncoderAttrH264CBR']]],
  ['gopsize',['gopsize',['../struct_i_m_p_encoder_g_o_p_size_cfg.html#ad09932e39efcb8aef9c2d344fbedffea',1,'IMPEncoderGOPSizeCfg']]],
  ['groupid',['groupID',['../struct_i_m_p_cell.html#a0faf27666324d237d67722b9fe517a69',1,'IMPCell']]]
];
