/*-----------------------------------------------------------------------------
  This confidential and proprietary software/information may be used only
  as authorized by a licensing agreement from Apical Limited

  (C) COPYRIGHT 2011 - 2014 Apical Limited
  ALL RIGHTS RESERVED

  The entire notice above must be reproduced on all authorized
  copies and copies may only be made to the extent permitted
  by a licensing agreement from Apical Limited.
  -----------------------------------------------------------------------------*/

#include "system_spi.h"

uint32_t spi_rw32(uint32_t sel_mask,uint32_t control,uint32_t data,uint8_t data_size)
{
	return 0;
}

uint32_t spi_rw48(uint32_t sel_mask, uint32_t control, uint32_t addr,uint8_t addr_size, uint32_t data,uint8_t data_size)
{
	return 0;
}

void spi_init_access(void)
{
}
