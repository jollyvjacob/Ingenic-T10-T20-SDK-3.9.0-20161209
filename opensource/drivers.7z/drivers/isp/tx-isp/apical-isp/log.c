#include "log.h"
const char * const log_level[LOG_MAX] = {"","EMERG","ALERT","CRIT","ERR","WARNING","NOTICE","INFO","DEBUG"};
