/*-----------------------------------------------------------------------------
  This confidential and proprietary software/information may be used only
  as authorized by a licensing agreement from Apical Limited

  (C) COPYRIGHT 2011 - 2014 Apical Limited
  ALL RIGHTS RESERVED

  The entire notice above must be reproduced on all authorized
  copies and copies may only be made to the extent permitted
  by a licensing agreement from Apical Limited.
  -----------------------------------------------------------------------------*/
#include "ApicalDefault.h"
#include <apical-isp/apical_configuration.h>
#include <apical-isp/apical_isp_config.h>
#include "apical_sbus.h"
#include "log.h"




void init_sensor_interface(sensor_ApicalDefault_iface_ptr_t p_iface)
{
}

void reset_sensor_interface(sensor_ApicalDefault_iface_ptr_t p_iface)
{
}

void load_sensor_interface(sensor_ApicalDefault_iface_ptr_t p_iface, uint8_t mode)
{
}
